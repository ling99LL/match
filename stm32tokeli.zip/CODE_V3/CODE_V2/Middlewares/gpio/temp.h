#ifndef TEMP_H
#define TEMP_H


extern float light,spo2_value,heart_value,angx_value,angy_value,angz_value,gases,jindu,weidu;
extern u8 table2[8];
void change(u16 num);
#endif

