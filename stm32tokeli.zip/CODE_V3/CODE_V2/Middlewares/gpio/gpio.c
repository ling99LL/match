
/********************************************************************************

//���빦�ܣ�  ��׼�� GPIO ����

//STM32F4����ģ��-�⺯���汾
//DevEBox  0
//�Ա����̣�0
//�Ա����̣�0	

*******************************************************************************/
  
#include "gpio.h"
 
//��ʼ��LED2--PC13   ��ʹ������ڵ�ʱ��		IO��ʼ��    

void GPIO_Config(void)
{
  GPIO_InitTypeDef GPIO_InitStructure;
  
////   /* Output HSE clock on MCO1 pin(PA8) ****************************************/ 
////  /* Enable the GPIOA peripheral */ 
////  RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOA, ENABLE);
////  
////  /* Configure MCO1 pin(PA8) in alternate function */
////  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_8;
////  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;
////  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF;
////  GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
////  GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;  
////  GPIO_Init(GPIOA, &GPIO_InitStructure);
////    
////  /* HSE clock selected to output on MCO1 pin(PA8)*/
////  RCC_MCO1Config(RCC_MCO1Source_HSE, RCC_MCO1Div_1);
  
  /* ��ʼ����Ӧ��IO�ӿ� PC13   LED on C13 pin(PC13) ***********************************/ 
  /* Enable the GPIOCperipheral */ 
  RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOB, ENABLE);
  
  /* Configure C13 pin(PC13) in output function */
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_6;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;
  GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
  GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_NOPULL;  
  GPIO_Init(GPIOB, &GPIO_InitStructure);
   GPIO_SetBits(GPIOB,GPIO_Pin_6);
	 
	 RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOC, ENABLE);
  
  /* Configure C13 pin(PC13) in output function */
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_13;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;
  GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
  GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_NOPULL;  
  GPIO_Init(GPIOC, &GPIO_InitStructure);
   GPIO_ResetBits(GPIOC,GPIO_Pin_13);

//  RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOA, ENABLE);
//  
//  /* Configure C13 pin(PC13) in output function */
//  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_8;
//  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_2MHz;
//  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;
//  GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
//  GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_NOPULL;  
//  GPIO_Init(GPIOA, &GPIO_InitStructure);
//   GPIO_ResetBits(GPIOA,GPIO_Pin_8);
	 
}





























/********************************************************************************

//STM32F4����ģ��-�⺯���汾
//DevEBox  0
//�Ա����̣�0
//�Ա����̣�0	

*******************************************************************************/






