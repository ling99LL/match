#ifndef __SHOW_H
#define __SHOW_H


void show_line(void);
void show_time_date(void);
void show_N_E(void);

#endif
