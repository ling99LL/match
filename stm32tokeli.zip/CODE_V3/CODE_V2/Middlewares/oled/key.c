#include "key.h"
#include "serial.h"
#include "temp.h"
u8 table[15];

u8 i,j;
void EXTIX_Init(void)
{

NVIC_InitTypeDef   NVIC_InitStructure;
		GPIO_InitTypeDef  GPIO_InitStructure;
	EXTI_InitTypeDef   EXTI_InitStructure;

  


  RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOA|RCC_AHB1Periph_GPIOB|RCC_AHB1Periph_GPIOC, ENABLE);			//ʹ��GPIOA,ʱ��

//GPIO_PinRemapConfig(GPIO_Remap_SWJ_JTAGDisable,ENABLE);
 GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0|GPIO_Pin_6|GPIO_Pin_5|GPIO_Pin_8|GPIO_Pin_4|GPIO_Pin_7;									//WK_UP��Ӧ����PA0--K0����
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN;							//��ͨ����ģʽ
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;				//100M
  GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP ;						  //����
  GPIO_Init(GPIOA, &GPIO_InitStructure);										//��ʼ��G
	
	

 
 

		
		

//		
//		

		
  /* ����EXTI_Line0 */

			SYSCFG_EXTILineConfig(EXTI_PortSourceGPIOA, EXTI_PinSource6);//PA6 ���ӵ��ж���4
	EXTI_InitStructure.EXTI_Line = EXTI_Line6;              //LINE0
  EXTI_InitStructure.EXTI_Mode = EXTI_Mode_Interrupt;     //�ж��¼�
  EXTI_InitStructure.EXTI_Trigger = EXTI_Trigger_Falling; //�½��ش��� 
  EXTI_InitStructure.EXTI_LineCmd = ENABLE;               //ʹ��LINE0
  EXTI_Init(&EXTI_InitStructure);//����
//	
//	
	SYSCFG_EXTILineConfig(EXTI_PortSourceGPIOA, EXTI_PinSource8);//PA6 ���ӵ��ж���4
	EXTI_InitStructure.EXTI_Line = EXTI_Line8;              //LINE0
  EXTI_InitStructure.EXTI_Mode = EXTI_Mode_Interrupt;     //�ж��¼�
  EXTI_InitStructure.EXTI_Trigger = EXTI_Trigger_Falling; //�½��ش��� 
  EXTI_InitStructure.EXTI_LineCmd = ENABLE;               //ʹ��LINE0
  EXTI_Init(&EXTI_InitStructure);//����
//	
	SYSCFG_EXTILineConfig(EXTI_PortSourceGPIOA, EXTI_PinSource5);//PA6 ���ӵ��ж���4
	EXTI_InitStructure.EXTI_Line = EXTI_Line5;              //LINE0
  EXTI_InitStructure.EXTI_Mode = EXTI_Mode_Interrupt;     //�ж��¼�
  EXTI_InitStructure.EXTI_Trigger = EXTI_Trigger_Falling; //�½��ش��� 
  EXTI_InitStructure.EXTI_LineCmd = ENABLE;               //ʹ��LINE0
  EXTI_Init(&EXTI_InitStructure);//����
	
	SYSCFG_EXTILineConfig(EXTI_PortSourceGPIOA, EXTI_PinSource0);//PA6 ���ӵ��ж���4
	EXTI_InitStructure.EXTI_Line = EXTI_Line0;              //LINE0
  EXTI_InitStructure.EXTI_Mode = EXTI_Mode_Interrupt;     //�ж��¼�
  EXTI_InitStructure.EXTI_Trigger = EXTI_Trigger_Falling; //�½��ش��� 
  EXTI_InitStructure.EXTI_LineCmd = ENABLE;               //ʹ��LINE0
  EXTI_Init(&EXTI_InitStructure);//����
SYSCFG_EXTILineConfig(EXTI_PortSourceGPIOA, EXTI_PinSource7);//PA6 ���ӵ��ж���4
	EXTI_InitStructure.EXTI_Line = EXTI_Line7;              //LINE0
  EXTI_InitStructure.EXTI_Mode = EXTI_Mode_Interrupt;     //�ж��¼�
  EXTI_InitStructure.EXTI_Trigger = EXTI_Trigger_Falling; //�½��ش��� 
  EXTI_InitStructure.EXTI_LineCmd = ENABLE;               //ʹ��LINE0
  EXTI_Init(&EXTI_InitStructure);//����
//	
  SYSCFG_EXTILineConfig(EXTI_PortSourceGPIOB, EXTI_PinSource1);//PA6 ���ӵ��ж���4
	EXTI_InitStructure.EXTI_Line = EXTI_Line1;              //LINE0
  EXTI_InitStructure.EXTI_Mode = EXTI_Mode_Interrupt;     //�ж��¼�
  EXTI_InitStructure.EXTI_Trigger = EXTI_Trigger_Falling; //�½��ش��� 
  EXTI_InitStructure.EXTI_LineCmd = ENABLE;               //ʹ��LINE0
  EXTI_Init(&EXTI_InitStructure);//����
//	
	SYSCFG_EXTILineConfig(EXTI_PortSourceGPIOA, EXTI_PinSource4);//PA6 ���ӵ��ж���4
	EXTI_InitStructure.EXTI_Line = EXTI_Line4;              //LINE0
  EXTI_InitStructure.EXTI_Mode = EXTI_Mode_Interrupt;     //�ж��¼�
  EXTI_InitStructure.EXTI_Trigger = EXTI_Trigger_Falling; //�½��ش��� 
  EXTI_InitStructure.EXTI_LineCmd = ENABLE;               //ʹ��LINE0
  EXTI_Init(&EXTI_InitStructure);//����
//	

	
	NVIC_InitStructure.NVIC_IRQChannel = EXTI4_IRQn;//�ⲿ�ж�2
  NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0x00;//��ռ���ȼ�3
  NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0x02;//�����ȼ�2
  NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;//ʹ���ⲿ�ж�ͨ��
  NVIC_Init(&NVIC_InitStructure);//����
//	
	
	NVIC_InitStructure.NVIC_IRQChannel = EXTI1_IRQn;//�ⲿ�ж�2
  NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0x03;//��ռ���ȼ�3
  NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0x01;//�����ȼ�2
  NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;//ʹ���ⲿ�ж�ͨ��
  NVIC_Init(&NVIC_InitStructure);//����
	NVIC_InitStructure.NVIC_IRQChannel = EXTI9_5_IRQn;//�ⲿ�ж�2
  NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0x00;//��ռ���ȼ�3
  NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0x00;//�����ȼ�2
  NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;//ʹ���ⲿ�ж�ͨ��
  NVIC_Init(&NVIC_InitStructure);//����

}
u8	ui_Count;
u8  ready2;
//�ⲿ�жϳ�ʼ��	
void EXTI4_IRQHandler(void)
{
 	
	delay_ms(10);
	if(GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_4)==0)	//��ӦK1����
	{
				OLED_Clear(); 
				ui_Count++;
				ui_Count%=5;
		
				
		
		EXTI_ClearITPendingBit(EXTI_Line4); //���LINE0�ϵ��жϱ�־λ 				
	}		 
	
	EXTI_ClearITPendingBit(EXTI_Line4); //���LINE0�ϵ��жϱ�־λ 
  
	
}	

void EXTI0_IRQHandler(void)
{
 	
	delay_ms(10);
	if(GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_0)==0)	//��ӦK1����
	{
	
			change(gases);	
			if(gases>=80)
			{
				table[0]=33;
				table[1]=table2[1];
				table[2]=10;
				table[3]=table2[0];	
				table[4]=35;
				j=5;
	
			}
			else
			{
				
				table[0]=table2[1];
				table[1]=10;
				table[2]=table2[0];	
				table[3]=34;
				j=4;

			}
			for(i=0;i<j;i++)
		{
				USART_SendData(USART2,table[i]);
				while(!USART_GetFlagStatus(USART2,USART_FLAG_TC));
		}
		EXTI_ClearITPendingBit(EXTI_Line0); //���LINE0�ϵ��жϱ�־λ 				
	}		 
	
	EXTI_ClearITPendingBit(EXTI_Line0); //���LINE0�ϵ��жϱ�־λ 
  
	
}
u8 enter;
void EXTI9_5_IRQHandler(void)
{
 	
	delay_ms(10);
	if(GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_5)==0)	//��ӦK1����
	{	
			change(gases);	
			if(gases>=80)
			{
				table[0]=33;
				table[1]=table2[1];
				table[2]=10;
				table[3]=table2[0];	
				table[4]=35;
				j=5;
	
			}
			else
			{
				
				table[0]=table2[1];
				table[1]=10;
				table[2]=table2[0];	
				table[3]=34;
				j=4;

			}
			for(i=0;i<j;i++)
		{
				USART_SendData(USART2,table[i]);
				while(!USART_GetFlagStatus(USART2,USART_FLAG_TC));
		}
		EXTI_ClearITPendingBit(EXTI_Line5); //���LINE0�ϵ��жϱ�־λ 			
	}
	if(GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_6)==0)	//��ӦK1����
	{
		OLED_Clear();
		enter++;
		enter%=2;
		if(enter==0)
		{
			switch(ui_Count)
		{
				case 0:
						OLED_DrawBMP1(35,1,60,40);//����Ѫ��
				break;
			case 1:OLED_DrawBMP2(35,0,50,50);//����ǿ��
				break;
			case 2:OLED_DrawBMP3(35,0,50,50);//������
				break;
			case 3:OLED_DrawBMP4(35,0,50,50);//��������
				break;
			case 4:show_line();		//
				break;
		}
	
	}
	else
		{
			switch(ui_Count)
		{
				case 0:
						OLED_Show1();//����Ѫ��
				break;
			case 1:OLED_Show2();//����Ѫ��
				break;
			case 2:OLED_Show3();//������
				break;
			case 3:OLED_Show4();//��������
				break;
			case 4:show_N_E();//��������
				break;
		}
					
		}
				EXTI_ClearITPendingBit(EXTI_Line6); //���LINE0�ϵ��жϱ�־λ 
}	
	if(GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_7)==0)
	{
		change(light);			
		if(light>100)
			{
				LED2=1; //�صƣ�
				table[0]=15;
				table[1]=table2[2];
				table[2]=11;
				table[3]=table2[1];
				table[4]=10;
				table[5]=table2[0];	
				table[6]=31;
				j=7;

			}
			else
			{
				LED2=0; //�صƣ�
				if(light>10)
				{
						table[0]=table2[1];
						table[1]=10;
						table[2]=table2[0];	
						table[3]=32;
						j=4;

				}
				else
				{
						table[0]=table2[0];			
						table[1]=32;
						j=2;

				}
			}
			for(i=0;i<j;i++)
		{
				USART_SendData(USART2,table[i]);
				while(!USART_GetFlagStatus(USART2,USART_FLAG_TC));
		}
		
		EXTI_ClearITPendingBit(EXTI_Line7); //���LINE0�ϵ��жϱ�־λ 
	}
	
	if(GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_8)==0)
	{			
//		OLED_Show1();//����Ѫ��
		if((heart_value>150)||(spo2_value<80))
				{
					if((heart_value>100))
					{
						change((int)heart_value);
						table[0]=36;
						table[1]=table2[2];
						table[2]=11;
						table[3]=table2[1];
						table[4]=10;
						table[5]=table2[0];
						change((int)spo2_value);
						table[6]=37;
						table[7]=table2[1];
						table[8]=10;
						table[9]=table2[0];	
						table[10]=39;
						j=11;
					}
					else
					{
						table[0]=36;
						table[1]=table2[1];
						table[2]=10;
						table[3]=table2[0];
						change((int)spo2_value);
						table[4]=37;
						table[5]=table2[1];
						table[6]=10;
						table[7]=table2[0];	
						table[8]=39;
						j=9;
						
					}
					
				}			
			else
			{
					
					if(heart_value>100)
					{
						change((int)heart_value);
						table[0]=table2[2];
						table[1]=11;
						table[2]=table2[1];
						table[3]=10;
						table[4]=table2[0];
						change((int)spo2_value);
						table[5]=37;
						table[6]=table2[1];
						table[7]=10;
						table[8]=table2[0];	
						table[9]=38;
						j=10;

					}
					else
					{
					
						change(heart_value);
						table[0]=table2[1];
						table[1]=10;
						table[2]=table2[0];
						change(spo2_value);
						table[3]=37;
						table[4]=table2[1];
						table[5]=10;
						table[6]=table2[0];	
						table[7]=38;
						j=8;
					}
		
	}
				for(i=0;i<j;i++)
		{
				USART_SendData(USART2,table[i]);
				while(!USART_GetFlagStatus(USART2,USART_FLAG_TC));
		}
		
		EXTI_ClearITPendingBit(EXTI_Line8); //���LINE0�ϵ��жϱ�־λ 
	}
	EXTI_ClearITPendingBit(EXTI_Line5|EXTI_Line6|EXTI_Line7|EXTI_Line8); //���LINE0�ϵ��жϱ�־λ s
	
}	

  

