#ifndef __HEX_CHAR_H
#define __HEX_CHAR_H

char hex_to_char(uint16_t hex1);

#endif
