#ifndef __XIIC_H
#define __XIIC_H
#include "stm32f4xx.h"            // Device header
#include "delay.h"

#define SDA_IN()  {GPIOB->MODER&=~(3<<(7*2));GPIOB->MODER|=0<<7*2;}	//PB9����ģʽ
#define SDA_OUT() {GPIOB->MODER&=~(3<<(7*2));GPIOB->MODER|=1<<7*2;} //PB9���ģʽ
//IO��������	 
#define IIC_SCL    PBout(8) //SCL
#define IIC_SDA    PBout(7) //SDA	 
#define READ_SDA   PBin(7)  //����SDA 


void IIC_GPIO_INIT(void);
void IIC_Start(void);
void IIC_Stop(void);
void IIC_Send_Byte(uint8_t byte);
void IIC_Ack(void);
void IIC_NAck(void);
uint8_t IIC_Receive_Byte(unsigned char ack);

uint8_t IIC_Read_Byte(uint8_t device_addr,uint8_t register_addr);
uint8_t IIC_Write_Byte(uint8_t device_addr,uint8_t register_addr,uint8_t data);

uint8_t IIC_Read_Array(uint8_t device_addr,u16 register_addr,uint8_t *Data,u16 Num);
uint8_t IIC_Write_Array(uint8_t device_addr,u16 register_addr,u8 *Data,u16 Num);

extern uint8_t ack_max70102;
#endif


















